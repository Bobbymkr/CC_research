#!/bin/bash
# RAASA eBPF Syscall Rate Probe (Sidecar)
#
# This script uses bpftrace to count syscalls per cgroup, maps the cgroup ID
# to the corresponding Kubernetes pod UID, and writes the per-second rate
# to /var/run/raasa/<pod-uid>/syscall_rate.
#
# This is a production-grade component for Phase 2 that replaces the synthetic
# CPU-based simulated syscall estimation.
#
# Requirements: bpftrace, bc, root privileges (SYS_ADMIN)

POLL_INTERVAL=${POLL_INTERVAL:-5}
PROBE_DIR="/var/run/raasa"
mkdir -p "$PROBE_DIR"

echo "Starting RAASA eBPF syscall probe (interval: ${POLL_INTERVAL}s)..."

# Global associative array for cgroup_inode -> pod_uid mapping
declare -gA CGROUP_MAP

# Map cgroup v2 inodes to Pod UIDs
# In cgroup v2, the cgroup ID returned by BPF is the inode number of the cgroup directory.
function build_cgroup_map() {
    CGROUP_MAP=()
    # Search kubepods slice (works for K3s/EKS/GKE)
    for cg in $(find /sys/fs/cgroup/kubepods.slice/ -type d \( -name "kubepods-pod*.slice" -o -name "kubepods-burstable-pod*.slice" \) 2>/dev/null); do
        local inode=$(stat -c %i "$cg" 2>/dev/null)
        if [[ -z "$inode" ]]; then continue; fi
        
        # Extract UID from slice name (e.g., kubepods-pod1234_5678.slice -> 1234_5678 -> 1234-5678)
        local uid=$(basename "$cg" | sed -E 's/kubepods(-burstable)?-pod(.*)\.slice/\2/')
        uid=${uid//_/-}
        
        CGROUP_MAP[$inode]=$uid
    done
}

# 1. Start bpftrace in the background
# It aggregates raw_syscalls:sys_enter by cgroup and dumps every $POLL_INTERVAL seconds.
bpftrace -e '
tracepoint:raw_syscalls:sys_enter {
    @[cgroup] = count();
}
interval:s:'"${POLL_INTERVAL}"' {
    print(@);
    clear(@);
}
' > /tmp/bpftrace_output &
BPF_PID=$!

cleanup() {
    echo "Stopping eBPF probe..."
    kill $BPF_PID 2>/dev/null
    exit 0
}
trap cleanup SIGINT SIGTERM

# 2. Main processing loop
while true; do
    sleep $POLL_INTERVAL
    build_cgroup_map
    
    # Atomically move the output to process it without race conditions
    cp /tmp/bpftrace_output /tmp/bpftrace_current
    > /tmp/bpftrace_output 
    
    # Process the output lines: @[cgroup_id]: count
    grep "^@\[" /tmp/bpftrace_current | while read -r line; do
        if [[ $line =~ \@\[([0-9]+)\]:\ ([0-9]+) ]]; then
            cg_id="${BASH_REMATCH[1]}"
            count="${BASH_REMATCH[2]}"
            
            uid="${CGROUP_MAP[$cg_id]}"
            if [[ -n "$uid" ]]; then
                # Calculate rate per second
                rate=$(echo "scale=2; $count / $POLL_INTERVAL" | bc -l)
                
                # Write to the shared probe directory exactly where RAASA expects it
                mkdir -p "${PROBE_DIR}/${uid}"
                echo "$rate" > "${PROBE_DIR}/${uid}/syscall_rate"
            fi
        fi
    done
done
