"""
Kubernetes-native enforcement backend for RAASA v2.

Replaces ``raasa/core/enforcement.py`` (Docker backend) when RAASA is
running in ``--backend k8s`` mode on a real Linux host inside an AWS EC2
instance.

Enforcement Mechanisms
----------------------
CPU throttling:
    Achieved by patching the Kubernetes Pod's resource limits via the
    K8s API.  When the API client is unavailable (development mode),
    falls back to a silent no-op so the controller loop continues.

Network throttling (primary v2 signal):
    Uses Linux Traffic Control (``tc``) to impose a token-bucket filter
    (TBF) on the pod's virtual network interface.  Bandwidth limits by
    tier::

        L1 → 1000 mbit/s  (unrestricted)
        L2 →  100 mbit/s  (moderate)
        L3 →    1 mbit/s  (near-isolation — enough to keep forensics alive)

    The L3 limit is intentionally NOT zero.  Completely cutting network
    kills the container's ability to send audit events back to the
    controller, defeating the OODA loop's Audit phase.  1 mbit renders
    exfiltration attacks economically infeasible whilst preserving the
    telemetry channel — a core safe-autonomy design decision.

Memory enforcement (cgroups v2):
    Writes directly to ``/sys/fs/cgroup/<pod-cgroup>/memory.max`` using
    the pod's UID obtained from the K8s API.  Gracefully skips if the
    cgroup path does not exist (e.g. when running outside a real node).

Privilege Requirement
---------------------
``tc`` and cgroup writes require the process to run as root::

    sudo -E env PYTHONPATH=. python -m raasa.core.app --backend k8s

The Docker ``ActionEnforcer`` does NOT require root; this is the main
runtime distinction between the two backends.

Interface Contract
------------------
``EnforcerK8s`` intentionally mirrors the ``ActionEnforcer`` public API:
``__init__(cpus_by_tier=...)`` and ``apply(decisions)`` — ensuring that
``app.py``'s factory function can inject either backend transparently.
"""
from __future__ import annotations

import logging
import os
import subprocess
from pathlib import Path
from typing import Dict, Iterable, Optional

from raasa.core.models import PolicyDecision, Tier

logger = logging.getLogger(__name__)


def _is_root() -> bool:
    """
    Check if the current process has root/admin privileges.
    Cross-platform: always returns False on Windows (tc/cgroups don't exist there).
    On POSIX (Linux/macOS), checks os.getuid() == 0.
    """
    if os.name == "nt":   # Windows — tc and cgroups are Linux-only
        return False
    return os.getuid() == 0  # type: ignore[attr-defined]  # POSIX only


# ── Tier → bandwidth mapping ──────────────────────────────────────────────────
# Used by _apply_network_throttle(). Values are tc TBF rate strings.
BANDWIDTH_BY_TIER: Dict[str, str] = {
    "L1": "1000mbit",   # Full throughput — no restriction
    "L2": "100mbit",    # Moderate throttle — suspicious workloads
    "L3": "1mbit",      # Near-isolation — confirmed malicious, kept alive for forensics
}

# Burst and latency parameters for the tc TBF qdisc.
# burst=32kbit  — minimum burst size; must satisfy: burst >= rate/HZ (HZ=250 on Linux)
# latency=400ms — maximum time a packet can sit in the queue before being dropped
TC_BURST = "32kbit"
TC_LATENCY = "400ms"

# ── Memory limit by tier (bytes) ──────────────────────────────────────────────
# Written to /sys/fs/cgroup/<cgroup>/memory.max when cgroup path is known.
MEMORY_BY_TIER: Dict[str, int] = {
    "L1": -1,                      # -1 → write "max" (unlimited)
    "L2": 512 * 1024 * 1024,       # 512 MiB
    "L3": 128 * 1024 * 1024,       # 128 MiB
}


def _run_tc(args: list[str]) -> bool:
    """Run a tc command. Returns True on success, False on any failure."""
    try:
        result = subprocess.run(
            ["tc"] + args,
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            # tc returns non-zero for harmless cases (e.g. 'del' when nothing exists)
            logger.debug(f"[tc] {' '.join(args)} → rc={result.returncode}: {result.stderr.strip()}")
        return result.returncode == 0
    except FileNotFoundError:
        logger.warning("[EnforcerK8s] 'tc' binary not found. Is iproute2 installed?")
        return False
    except Exception as exc:
        logger.warning(f"[EnforcerK8s] tc command failed: {exc}")
        return False


def _detect_pod_interface(pod_id: str) -> str:
    """
    Attempt to detect the primary network interface for a pod.

    In a real DaemonSet, this uses the pod's netns to identify the veth
    pair.  For the prototype, we use 'eth0' as the universal default since
    all K3s pods see eth0 as their primary interface inside the netns.
    Future work: resolve via 'ip netns exec <pod-netns> ip link'.
    """
    return "eth0"


class EnforcerK8s:
    """
    Kubernetes-native enforcement backend.

    Applies containment via Linux Traffic Control (tc) and cgroups v2
    instead of the Docker ``update --cpus`` command used in v1.

    Parameters
    ----------
    cpus_by_tier:
        CPU quota mapping (kept for API parity with ActionEnforcer).
        Currently informational only — CPU enforcement is planned via
        the Kubernetes resource limit PATCH in a future sub-iteration.
    cgroup_base_path:
        Base cgroup v2 directory.  Override in tests with a tmpdir.
    """

    def __init__(
        self,
        cpus_by_tier: Optional[Dict[str, float]] = None,
        cgroup_base_path: str = "/sys/fs/cgroup",
    ) -> None:
        self.cpus_by_tier = cpus_by_tier or {"L1": 1.0, "L2": 0.5, "L3": 0.2}
        self.cgroup_base_path = Path(cgroup_base_path)
        self.last_applied_tier: Dict[str, str] = {}

        # Warn once at startup if we are not root (enforcement will silently
        # fail, but the controller loop will still run — safe fallback).
        if not _is_root():
            logger.warning(
                "[EnforcerK8s] Not running as root. "
                "tc and cgroup enforcement will be silently skipped. "
                "Re-run with: sudo -E env PYTHONPATH=. python -m raasa.core.app --backend k8s"
            )

    # ── Public API (mirrors ActionEnforcer) ────────────────────────────────────

    def apply(self, decisions: Iterable[PolicyDecision]) -> None:
        """Apply all enforcement decisions. Idempotent per (container_id, tier)."""
        for decision in decisions:
            tier = decision.applied_tier.value
            cid = decision.container_id

            # Skip if tier has not changed — identical to Docker enforcer behaviour
            if self.last_applied_tier.get(cid) == tier:
                continue

            interface = _detect_pod_interface(cid)
            net_ok = self._apply_network_throttle(cid, tier, interface)
            mem_ok = self._apply_memory_limit(cid, tier)

            if net_ok or mem_ok:
                logger.info(
                    f"[EnforcerK8s] {cid} → {tier} "
                    f"(net={'✓' if net_ok else '✗'}, mem={'✓' if mem_ok else '✗'})"
                )
            self.last_applied_tier[cid] = tier

    # ── Private enforcement methods ────────────────────────────────────────────

    def _apply_network_throttle(self, pod_id: str, tier: str, interface: str) -> bool:
        """
        Apply a Token Bucket Filter (TBF) to limit egress bandwidth.

        TBF is the simplest and most predictable Linux qdisc for bandwidth
        capping.  It does NOT add latency beyond the bucket drain time,
        which keeps forensic telemetry channels alive even at L3.

        Steps:
            1. Delete any existing root qdisc (idempotent).
            2. Add new TBF with target bandwidth.
        """
        if not _is_root():
            logger.debug(f"[EnforcerK8s] Skipping tc (not root) for {pod_id}")
            return False

        bandwidth = BANDWIDTH_BY_TIER.get(tier, "1000mbit")

        # Step 1: Delete existing root qdisc — safe to fail if none exists
        _run_tc(["qdisc", "del", "dev", interface, "root"])

        # Step 2: Add TBF
        ok = _run_tc([
            "qdisc", "add", "dev", interface,
            "root", "tbf",
            "rate", bandwidth,
            "burst", TC_BURST,
            "latency", TC_LATENCY,
        ])
        if ok:
            logger.info(
                f"[EnforcerK8s] tc: {pod_id} ({interface}) "
                f"→ {tier} at {bandwidth}"
            )
        else:
            logger.warning(
                f"[EnforcerK8s] tc: failed to set {bandwidth} on {interface} for {pod_id}"
            )
        return ok

    def _apply_memory_limit(self, pod_id: str, tier: str) -> bool:
        """
        Write a memory.max limit to the pod's cgroup v2 slice.

        In a K3s cluster, kubepods' cgroups live under:
            /sys/fs/cgroup/kubepods.slice/

        We search for a subtree containing the pod UID (injected via the
        K8s API in a future iteration).  For the prototype, we perform a
        glob search for any cgroup directory containing the pod_id string.

        Falls back silently if the cgroup path is not found — this is
        expected in development environments.
        """
        if not _is_root():
            logger.debug(f"[EnforcerK8s] Skipping cgroup write (not root) for {pod_id}")
            return False

        limit_bytes = MEMORY_BY_TIER.get(tier, -1)
        limit_str = "max" if limit_bytes == -1 else str(limit_bytes)

        # Search for pod-specific cgroup slice
        cgroup_candidates = list(self.cgroup_base_path.glob(
            f"kubepods.slice/**/{pod_id[:12]}*/memory.max"
        ))

        if not cgroup_candidates:
            logger.debug(
                f"[EnforcerK8s] No cgroup path found for {pod_id} — "
                f"skipping memory enforcement (expected outside a real K3s node)."
            )
            return False

        success = False
        for mem_max_path in cgroup_candidates:
            try:
                mem_max_path.write_text(limit_str, encoding="utf-8")
                logger.info(
                    f"[EnforcerK8s] cgroup: {pod_id} memory.max → {limit_str} "
                    f"({mem_max_path})"
                )
                success = True
            except OSError as exc:
                logger.warning(f"[EnforcerK8s] cgroup write failed for {mem_max_path}: {exc}")

        return success
